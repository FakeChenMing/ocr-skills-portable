#!/usr/bin/env python3
"""Install only the four portable skills; preserve existing installations by default."""
import argparse
import os
from pathlib import Path
import shutil
import uuid

NAMES = ('mineru-document-parsing', 'mineru-document-extractor',
         'paddleocr-text-recognition', 'paddleocr-doc-parsing')

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    default = Path(os.environ.get('CODEX_HOME', Path.home() / '.codex')) / 'skills'
    parser.add_argument('--skills-dir', type=Path, default=default)
    parser.add_argument('--replace', action='store_true')
    parser.add_argument('--dry-run', action='store_true')
    args = parser.parse_args()
    source = Path(__file__).resolve().parent / 'skills'
    dest = args.skills_dir.expanduser().resolve()
    for name in NAMES:
        if not (source / name / 'SKILL.md').is_file():
            parser.error(f'Missing skill: {name}')
        if (dest / name).is_symlink():
            parser.error(f'Refusing symlink destination: {dest / name}')
        if (dest / name).exists() and not args.replace:
            parser.error(f'Already exists: {dest / name}; use --replace to back up first')
        if dest == source or source in dest.parents or dest in source.parents:
            parser.error('Destination must not overlap package source')
    print(f'Install {len(NAMES)} skills to {dest}; replace={args.replace}')
    if args.dry_run:
        return
    dest.mkdir(parents=True, exist_ok=True)
    backup = dest / '.ocr-backups' / uuid.uuid4().hex
    installed, moved = [], []
    try:
        for name in NAMES:
            target = dest / name
            if target.exists():
                backup.mkdir(parents=True, exist_ok=True)
                shutil.move(str(target), str(backup / name))
                moved.append(name)
            # Track partial copies as well, so rollback removes them.
            installed.append(name)
            shutil.copytree(source / name, target)
    except BaseException:
        for name in reversed(installed):
            if (dest / name).exists():
                shutil.rmtree(dest / name)
        for name in moved:
            shutil.move(str(backup / name), str(dest / name))
        raise
    print('Skills installed. Reload skills; runtime/models require separate setup.')
    if moved:
        print(f'Previous skills preserved at {backup}')

if __name__ == '__main__':
    main()
