---
name: mineru-document-parsing
description: "Route OCR and document parsing by expected accuracy first and end-to-end speed second, without preferring local or cloud deployment: PP-OCRv6 for plain text images and screenshots, MinerU Pipeline for standard or large structured documents, MinerU Hybrid for complex multi-page documents, PaddleOCR-VL-1.6 for distorted scans, seals, ancient or rare Chinese, difficult tables, formulas, charts, and targeted PaddleOCR repair for failed regions. Recover known MinerU sandbox process-pool permission failures by rerunning outside the restricted environment. Use for every OCR, image-to-text, PDF-to-Markdown, scanned-document extraction, table or formula extraction, document digitization, and knowledge-base ingestion request."
---

# Adaptive OCR and document parsing

Choose the engine by this strict priority order:

1. Expected output accuracy and structural fidelity for the actual input.
2. End-to-end completion time among options with comparable accuracy, including upload and download time, queueing, page limits, chunking, model startup, inference, retries, merging, and verification.
3. Operational cost and convenience only after accuracy and speed.

Do not prefer local or cloud deployment merely because of where processing occurs. Do not treat privacy, upload avoidance, or external transmission as a selection factor unless the user explicitly imposes that constraint for the current task. Do not run two complete OCR passes by default when targeted verification or repair can achieve the same accuracy faster.

## Backend policy

1. Discover these local commands as candidates, not as guaranteed installations or preferred candidates:
   - `mineru`
   - `paddleocr`
2. Use PP-OCRv6 directly for screenshots, photos, and scans when the requested output is plain text or coordinates and document structure is unimportant.
3. Use MinerU `pipeline` for standard structured documents, simple tables, long clean PDFs, and large batches.
4. Use MinerU `hybrid-engine --effort medium` for multi-column or mixed-content multi-page documents and semantic continuity across pages.
5. Use MinerU `hybrid-engine --effort high` for cross-page tables, image understanding, or critical complex multi-page documents where maximum accuracy justifies extra runtime.
6. Use PaddleOCR-VL-1.6 for warped, skewed, photographed, poorly lit, or irregular scans; seals; ancient books; rare Chinese characters; and visually difficult tables, formulas, or charts. Prefer it for a failed page or crop instead of rerunning an entire long document when that preserves accuracy and reduces total time.
7. Compare local and remote implementations symmetrically. Choose remote when it is expected to be more accurate, or when accuracy is comparable and it is faster end to end. Choose local under the same test. A cloud page limit is a feasibility and timing factor: chunk the document or switch engines according to expected accuracy and total completion time, never merely to avoid external transmission.
8. Never state or imply that local OCR was selected to protect privacy unless the user explicitly requested a privacy constraint for that task.

## 1. Establish capabilities

1. Establish which local and remote OCR backends are actually available, including credentials, supported formats, page limits, queueing, cached models, hardware acceleration, and startup cost.
2. Inspect document type, length, scan quality, distortion, layout complexity, formulas, tables, charts, seals, rare characters, and language before selecting PP-OCRv6, MinerU, or PaddleOCR-VL-1.6.
3. Estimate accuracy first, then end-to-end time. For a large job, benchmark representative difficult and normal pages when the best route is uncertain and the benchmark is likely to save time overall.
4. If a selected backend is unavailable, disclose that fact and use the next-best available route. Do not pretend an unavailable backend ran.
5. On the target machine, do not infer that local PaddleOCR is unavailable merely because `PADDLEOCR_ACCESS_TOKEN` is unset. That token is required only for the cloud `paddleocr api` path; the installed local `paddleocr ocr` and `paddleocr doc_parser` paths use cached models and do not require it.
6. Before reporting a missing PaddleOCR command, check PATH and the target machine's configured virtual environment or launcher. Resolve its absolute executable path and use it consistently in scheduled tasks. Verify `ocr --help` and `doc_parser --help`; top-level help may omit lazy-loaded subcommands. Never assume models are cached on a new machine.

## Portable installation and instruction precedence

Read this routing skill first, then explicitly load the selected backend's sibling skill. This router's accuracy-first, speed-second, no local/cloud preference and machine-wide memory rules override backend skill defaults such as "start fast". Backend skills document interfaces, not unconditional routing decisions. Do not interpret missing cloud credentials as missing local functionality. Consult the repository README and MIGRATE.md for runtime setup; installing skill files does not install models. Check current CLI help before using the invocation templates below, and choose supported hardware settings on the target machine.

PP-OCRv6 is also subject to quality checks. If it fails, use an appropriate alternative for the affected region; skipping a redundant identical repair must not mean skipping verification.

## Parallel OCR and memory limit

Parallel OCR threads or worker processes are permitted when they improve end-to-end speed without reducing accuracy. Keep total system physical-memory usage, including other applications and all OCR workers, below 90%; this is a shared machine-wide budget, not a per-worker allowance.

- Before starting OCR and before adding each worker, measure system memory usage and estimate the additional worker's peak memory, including model loading, page rendering, and inference buffers. Start with one representative job when the peak is unknown; reuse loaded models where supported.
- Use 85% as the operational ceiling to leave headroom below the 90% limit. Add workers only when projected total usage remains below 85%. Monitor memory throughout processing, at least once per second and at each worker launch; coordinate concurrent OCR jobs against the same budget.
- At 85%, stop launching workers and reduce concurrent work. If usage reaches 90%, promptly cancel enough OCR workers owned by this task to release memory, preserve completed outputs, and requeue unfinished pages. Suspending a process alone does not release its memory. Never terminate unrelated applications or another task's workers.
- If usage is already at or above 90%, do not start local OCR. If reliable monitoring is unavailable or even one worker cannot fit within the budget, do not run unmonitored local OCR; use an available remote backend or report the resource limitation. Resume conservatively only after usage and projected peak are below 85%.
- Preserve page order, separate worker output paths, and merge without duplicates. Report peak observed memory and any throttling when material. External applications and sampling intervals can cause brief excursions; do not claim an absolute system-wide guarantee from monitoring alone.

## Runtime permission handling

1. MinerU Pipeline creates a `ProcessPoolExecutor` even for a one-page input. In a Codex managed or restricted shell where process semaphores are unavailable, run the installed `mineru-local` command outside the restricted environment from the outset by using the execution tool's escalated-sandbox permission. This is an execution requirement, not a reason to prefer local or cloud processing.
2. If MinerU fails at `os.sysconf("SC_SEM_NSEMS_MAX")`, `concurrent.futures.process._check_system_limits`, or `ProcessPoolExecutor` with `PermissionError: [Errno 1] Operation not permitted`, preserve the same input, output, backend, page range, and model settings and immediately rerun once outside the restricted environment. Do not diagnose the source file or model as damaged, and do not switch OCR engines solely because of this error.
3. If elevated execution is unavailable or denied, choose the next-best local or remote route by accuracy first and end-to-end speed second, and report the environment limitation briefly.
4. PaddleOCR may emit `sysctl ... Operation not permitted` while probing system information in a restricted shell. Treat this as a non-fatal warning when the command exits successfully and produces complete result files. Escalate or change routes only if inference fails or required output is missing.
5. Distinguish sandbox failures from ordinary path permissions. For missing source access or an unwritable output directory, use a readable source and an output directory inside an authorized writable root instead of escalating blindly.

## 2. Run the selected primary parser

For plain-text OCR, PP-OCRv6 is often the best candidate. The local invocation template is:

```bash
paddleocr ocr \
  -i <input_path> --save_path <output_directory> --device cpu \
  --ocr_version PP-OCRv6 --use_doc_orientation_classify False \
  --use_doc_unwarping False --use_textline_orientation False
```

For structured documents, parse with MinerU and preserve page numbers, block order, Markdown/JSON, extracted images, tables, and formulas.

The local MinerU invocation template is:

```bash
mineru \
  -p <input_path> -o <output_directory> -b pipeline
```

Apply the runtime permission rules above when executing this command. Do not stop after the known sandbox error if an outside-sandbox retry is authorized.

Escalate to `-b hybrid-engine --effort medium` or `high` only when document complexity or the user's accuracy requirement justifies it. Measure representative pages for large jobs before committing the whole document.

For the PaddleOCR-VL-1.6 specialty path, the local invocation template is:

```bash
paddleocr doc_parser \
  -i <input_path> --save_path <output_directory> \
  --pipeline_version v1.6 --device cpu --engine paddle
```

Keep orientation classification and unwarping enabled for photographed, rotated, curved, or perspective-distorted inputs. Disable them for flat, correctly oriented scans to reduce runtime. Keep chart and seal recognition enabled when those elements are present.

## 3. Detect exceptions page by page

Render or inspect the source when possible and flag only evidence-backed exceptions:

- a blank or nearly blank result despite visible source content;
- replacement characters, obvious mojibake, repeated junk, or severe text corruption;
- missing visible paragraphs, titles, columns, images, tables, formulas, charts, or seals;
- materially incorrect reading order;
- broken table structure, formula conversion, or layout segmentation;
- low confidence only when the tool actually supplies a confidence value and the applicable threshold is documented or user-defined.

Do not invent confidence values. Record the affected page and, when available, bounding box or region.

## 4. Repair exceptions with PaddleOCR

Route each exception to the narrowest available PaddleOCR capability:

- Use the local `paddleocr-local ocr` command for plain text, line-level text, or bounding boxes.
- Use local PaddleOCR-VL-1.6 for distorted regions, seals, rare characters, ancient text, difficult tables, formulas, and charts.
- Keep successful MinerU blocks unchanged. Prefer a cropped PaddleOCR-VL repair over a full-document second pass.

Process only failed pages or cropped regions. Skip this repair stage when PP-OCRv6 was already the primary parser. Expand to a full-document second pass only when failures are widespread and explain why.

## 5. Merge without duplication

1. Keep successful MinerU blocks unchanged.
2. Replace or supplement only the failed block or page with the PaddleOCR result.
3. Align by page number and coordinates when available.
4. Remove duplicate text created near region boundaries while preserving intentional repetition.
5. Preserve headings, lists, tables, formulas, images, and reading order.
6. Track provenance internally as `PP-OCRv6`, `MinerU`, `PaddleOCR-VL-1.6`, or `PaddleOCR repair` for each page or block.

## 6. Quality check and report

Compare the merged result with the source, focusing on repaired pages plus representative normal pages. Check completeness, character accuracy, reading order, tables, formulas, page continuity, and duplicates.

Return the requested content or artifact and briefly report:

- primary parser and backend actually used;
- repaired pages or regions and the PaddleOCR capability used;
- unresolved uncertainty or unreadable content;
- why the selected route won on expected accuracy and end-to-end speed;
- material chunking, retries, or backend limitations that affected the result.

Do not emphasize whether processing was local or remote unless it explains accuracy, timing, a limitation, or the user asks.

Never silently claim success when a required executable, model, credential, or source page is unavailable.
